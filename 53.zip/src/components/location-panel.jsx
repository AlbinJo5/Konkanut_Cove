import {Location} from '../svgrs/locations'
export default function LocationPanel(){
    return (
        <div className="my-2">
            <Location width="100%" height="100%"/>
        </div>
    );
}