export const Directions = {
    Left:0,
    Right:1
}